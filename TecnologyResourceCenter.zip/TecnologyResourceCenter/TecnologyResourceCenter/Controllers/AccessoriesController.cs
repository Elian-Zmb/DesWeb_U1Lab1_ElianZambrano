﻿using Microsoft.AspNetCore.Mvc;
using TecnologyResourceCenter.Models;
using System.Collections.Generic;
using System.Linq;

namespace TecnologyResourceCenter.Controllers
{
    public class AccessoriesController : Controller
    {
        private static List<Accessory> _accessories = new List<Accessory>
        {
            new Accessory { Id = 1, Name = "Wireless Microphone", Brand = "Rode", Category = "Audio", Price = 120.00m, Quantity = 5 },
            new Accessory { Id = 2, Name = "Webcam 1080p", Brand = "Logitech", Category = "Video", Price = 45.00m, Quantity = 8 },
            new Accessory { Id = 3, Name = "Aluminum Tripod", Brand = "Manfrotto", Category = "Video", Price = 65.00m, Quantity = 4 },
            new Accessory { Id = 4, Name = "USB-C Hub Multiport", Brand = "Anker", Category = "Connectivity", Price = 35.00m, Quantity = 12 },
            new Accessory { Id = 5, Name = "HDMI to VGA Adapter", Brand = "Ugreen", Category = "Connectivity", Price = 15.00m, Quantity = 15 },
            new Accessory { Id = 6, Name = "Gigabit Network Switch", Brand = "TP-Link", Category = "Networking", Price = 30.00m, Quantity = 6 },
            new Accessory { Id = 7, Name = "Wi-Fi 6 Router", Brand = "ASUS", Category = "Networking", Price = 90.00m, Quantity = 3 },
            new Accessory { Id = 8, Name = "Studio Headphones", Brand = "Audio-Technica", Category = "Audio", Price = 85.00m, Quantity = 7 },
            new Accessory { Id = 9, Name = "HDMI Capture Card", Brand = "Elgato", Category = "Video", Price = 110.00m, Quantity = 2 },
            new Accessory { Id = 10, Name = "Portable SSD 1TB", Brand = "Samsung", Category = "Storage", Price = 130.00m, Quantity = 10 },
            new Accessory { Id = 11, Name = "Mechanical Keyboard", Brand = "Keychron", Category = "Computing", Price = 75.00m, Quantity = 9 },
            new Accessory { Id = 12, Name = "Wireless Mouse", Brand = "Logitech", Category = "Computing", Price = 40.00m, Quantity = 14 },
            new Accessory { Id = 13, Name = "USB Condenser Mic", Brand = "Blue Yeti", Category = "Audio", Price = 100.00m, Quantity = 4 },
            new Accessory { Id = 14, Name = "External Hard Drive 2TB", Brand = "Seagate", Category = "Storage", Price = 80.00m, Quantity = 6 },
            new Accessory { Id = 15, Name = "Cat6 Ethernet Cable 10m", Brand = "AmazonBasics", Category = "Networking", Price = 12.00m, Quantity = 20 }
        };

        public IActionResult Index()
        {
            return View(_accessories.OrderBy(a => a.Id).ToList());
        }

        public IActionResult Details(int id)
        {
            var accessory = _accessories.FirstOrDefault(a => a.Id == id);
            if (accessory == null)
            {
                return NotFound();
            }
            return View(accessory);
        }

        public IActionResult ByCategory()
        {
            return View(_accessories);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Accessory accessory)
        {
            if (!ModelState.IsValid)
            {
                return View(accessory);
            }

            accessory.Id = _accessories.Any() ? _accessories.Max(a => a.Id) + 1 : 1;
            _accessories.Add(accessory);

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var accessory = _accessories.FirstOrDefault(a => a.Id == id);
            if (accessory == null) return NotFound();

            return View(accessory);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Accessory updatedAccessory)
        {
            if (id != updatedAccessory.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(updatedAccessory);
            }

            var existingAccessory = _accessories.FirstOrDefault(a => a.Id == id);
            if (existingAccessory == null) return NotFound();

            existingAccessory.Name = updatedAccessory.Name;
            existingAccessory.Brand = updatedAccessory.Brand;
            existingAccessory.Category = updatedAccessory.Category;
            existingAccessory.Price = updatedAccessory.Price;
            existingAccessory.Quantity = updatedAccessory.Quantity;

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var accessory = _accessories.FirstOrDefault(a => a.Id == id);
            if (accessory == null) return NotFound();

            return View(accessory);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var accessory = _accessories.FirstOrDefault(a => a.Id == id);
            if (accessory != null)
            {
                _accessories.Remove(accessory);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}