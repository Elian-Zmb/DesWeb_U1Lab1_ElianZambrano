﻿using Microsoft.AspNetCore.Mvc;
using TecnologyResourceCenter.Models;
using System.Collections.Generic;
using System.Linq;

namespace TecnologyResourceCenter.Controllers
{
    public class EquipmentController : Controller
    {
        private static List<Equipment> _equipments = new List<Equipment>
        {
            new Equipment { Id = 1, Name = "Laptop Dell Latitude", Category = "Computing", Brand = "Dell", DailyRate = 25.00m, Stock = 4, IsOperational = true },
            new Equipment { Id = 2, Name = "Proyector Epson PowerLite", Category = "Video", Brand = "Epson", DailyRate = 40.00m, Stock = 1, IsOperational = true },
            new Equipment { Id = 3, Name = "Cámara Sony Alpha", Category = "Video", Brand = "Sony", DailyRate = 50.00m, Stock = 0, IsOperational = true },
            new Equipment { Id = 4, Name = "Tablet iPad Pro", Category = "Computing", Brand = "Apple", DailyRate = 30.00m, Stock = 6, IsOperational = true },
            new Equipment { Id = 5, Name = "Router Cisco Enterprise", Category = "Networking", Brand = "Cisco", DailyRate = 20.00m, Stock = 3, IsOperational = true },
            new Equipment { Id = 6, Name = "Monitor LG UltraWide", Category = "Computing", Brand = "LG", DailyRate = 15.00m, Stock = 2, IsOperational = true },
            new Equipment { Id = 7, Name = "Micrófono Shure SM58", Category = "Audio", Brand = "Shure", DailyRate = 10.00m, Stock = 5, IsOperational = true },
            new Equipment { Id = 8, Name = "Impresora HP LaserJet", Category = "Office", Brand = "HP", DailyRate = 18.00m, Stock = 0, IsOperational = false },
            new Equipment { Id = 9, Name = "Switch Netgear 24-Port", Category = "Networking", Brand = "Netgear", DailyRate = 22.00m, Stock = 4, IsOperational = true },
            new Equipment { Id = 10, Name = "Workstation HP ZBook", Category = "Computing", Brand = "HP", DailyRate = 45.00m, Stock = 2, IsOperational = true },
            new Equipment { Id = 11, Name = "Cámara Web Logitech 4K", Category = "Video", Brand = "Logitech", DailyRate = 12.00m, Stock = 10, IsOperational = true },
            new Equipment { Id = 12, Name = "Tripod Manfrotto", Category = "Video", Brand = "Manfrotto", DailyRate = 8.00m, Stock = 7, IsOperational = true },
            new Equipment { Id = 13, Name = "Hub USB-C Anker", Category = "Connectivity", Brand = "Anker", DailyRate = 5.00m, Stock = 15, IsOperational = true },
            new Equipment { Id = 14, Name = "Adaptador HDMI a VGA", Category = "Connectivity", Brand = "Generic", DailyRate = 4.00m, Stock = 8, IsOperational = true },
            new Equipment { Id = 15, Name = "Disco Duro Externo 2TB", Category = "Storage", Brand = "Western Digital", DailyRate = 10.00m, Stock = 5, IsOperational = true },
            new Equipment { Id = 16, Name = "Teclado Mecánico RGB", Category = "Computing", Brand = "Corsair", DailyRate = 9.00m, Stock = 6, IsOperational = true },
            new Equipment { Id = 17, Name = "Mouse Ergonómico inalambrico", Category = "Computing", Brand = "Logitech", DailyRate = 6.00m, Stock = 12, IsOperational = true },
            new Equipment { Id = 18, Name = "Auriculares HyperX Cloud", Category = "Audio", Brand = "HyperX", DailyRate = 14.00m, Stock = 4, IsOperational = true },
            new Equipment { Id = 19, Name = "Capturadora Elgato HD60", Category = "Video", Brand = "Elgato", DailyRate = 28.00m, Stock = 1, IsOperational = true },
            new Equipment { Id = 20, Name = "SSD Portátil SanDisk 1TB", Category = "Storage", Brand = "SanDisk", DailyRate = 16.00m, Stock = 9, IsOperational = true }
        };

        public IActionResult Index()
        {
            return View(_equipments.OrderBy(e => e.Id).ToList());
        }

        public IActionResult Details(int id)
        {
            var equipment = _equipments.FirstOrDefault(e => e.Id == id);
            if (equipment == null) return NotFound();
            return View(equipment);
        }

        public IActionResult Available()
        {
            var availableEquipments = _equipments.Where(e => e.IsOperational && e.Stock > 0).ToList();
            return View(availableEquipments);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Equipment equipment)
        {
            if (!ModelState.IsValid)
            {
                return View(equipment);
            }

            equipment.Id = _equipments.Any() ? _equipments.Max(e => e.Id) + 1 : 1;

            _equipments.Add(equipment);

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var equipment = _equipments.FirstOrDefault(e => e.Id == id);
            if (equipment == null) return NotFound();

            return View(equipment);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Equipment updatedEquipment)
        {
            if (id != updatedEquipment.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(updatedEquipment);
            }

            var existingEquipment = _equipments.FirstOrDefault(e => e.Id == id);
            if (existingEquipment == null) return NotFound();

            existingEquipment.Name = updatedEquipment.Name;
            existingEquipment.Category = updatedEquipment.Category;
            existingEquipment.Brand = updatedEquipment.Brand;
            existingEquipment.DailyRate = updatedEquipment.DailyRate;
            existingEquipment.Stock = updatedEquipment.Stock;
            existingEquipment.IsOperational = updatedEquipment.IsOperational;

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var equipment = _equipments.FirstOrDefault(e => e.Id == id);
            if (equipment == null) return NotFound();

            return View(equipment);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var equipment = _equipments.FirstOrDefault(e => e.Id == id);
            if (equipment != null)
            {
                _equipments.Remove(equipment);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}