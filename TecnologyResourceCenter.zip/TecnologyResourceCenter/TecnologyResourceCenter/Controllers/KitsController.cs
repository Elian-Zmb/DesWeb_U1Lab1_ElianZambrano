﻿using Microsoft.AspNetCore.Mvc;
using TecnologyResourceCenter.Models;
using System.Collections.Generic;
using System.Linq;

namespace TecnologyResourceCenter.Controllers
{
    public class KitsController : Controller
    {
        private static List<Kit> _kits = new List<Kit>
        {
            new Kit { Id = 1, Name = "Arduino Starter Kit", Category = "Electronics", Level = "BEGINNER", DailyRate = 12.00m, Quantity = 8, IsOperational = true },
            new Kit { Id = 2, Name = "Electronics Basics Kit", Category = "Electronics", Level = "BEGINNER", DailyRate = 10.00m, Quantity = 5, IsOperational = true },
            new Kit { Id = 3, Name = "IoT Kit", Category = "Networking", Level = "INTERMEDIATE", DailyRate = 22.00m, Quantity = 4, IsOperational = true },
            new Kit { Id = 4, Name = "Robotics Kit", Category = "Robotics", Level = "INTERMEDIATE", DailyRate = 30.00m, Quantity = 2, IsOperational = true },
            new Kit { Id = 5, Name = "Artificial Intelligence Kit", Category = "AI", Level = "ADVANCED", DailyRate = 50.00m, Quantity = 3, IsOperational = true },
            new Kit { Id = 6, Name = "Advanced Networking Kit", Category = "Networking", Level = "ADVANCED", DailyRate = 45.00m, Quantity = 1, IsOperational = true },
            new Kit { Id = 7, Name = "Photography Kit", Category = "Media", Level = "INTERMEDIATE", DailyRate = 35.00m, Quantity = 6, IsOperational = true },
            new Kit { Id = 8, Name = "Streaming Kit", Category = "Media", Level = "ADVANCED", DailyRate = 40.00m, Quantity = 0, IsOperational = true },
            new Kit { Id = 9, Name = "Podcast Kit", Category = "Audio", Level = "BEGINNER", DailyRate = 18.00m, Quantity = 7, IsOperational = true },
            new Kit { Id = 10, Name = "Virtual Reality Kit", Category = "VR", Level = "ADVANCED", DailyRate = 55.00m, Quantity = 2, IsOperational = true }
        };

        public IActionResult Index()
        {
            return View(_kits.OrderBy(k => k.Id).ToList());
        }

        public IActionResult Details(int id)
        {
            var kit = _kits.FirstOrDefault(k => k.Id == id);
            if (kit == null)
            {
                return NotFound();
            }
            return View(kit);
        }

        public IActionResult ByLevel()
        {
            return View(_kits);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Kit kit)
        {
            if (!ModelState.IsValid)
            {
                return View(kit);
            }

            kit.Id = _kits.Any() ? _kits.Max(k => k.Id) + 1 : 1;
            _kits.Add(kit);

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var kit = _kits.FirstOrDefault(k => k.Id == id);
            if (kit == null) return NotFound();

            return View(kit);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Kit updatedKit)
        {
            if (id != updatedKit.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(updatedKit);
            }

            var existingKit = _kits.FirstOrDefault(k => k.Id == id);
            if (existingKit == null) return NotFound();

            existingKit.Name = updatedKit.Name;
            existingKit.Category = updatedKit.Category;
            existingKit.Level = updatedKit.Level;
            existingKit.DailyRate = updatedKit.DailyRate;
            existingKit.Quantity = updatedKit.Quantity;
            existingKit.IsOperational = updatedKit.IsOperational;

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var kit = _kits.FirstOrDefault(k => k.Id == id);
            if (kit == null) return NotFound();

            return View(kit);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var kit = _kits.FirstOrDefault(k => k.Id == id);
            if (kit != null)
            {
                _kits.Remove(kit);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}