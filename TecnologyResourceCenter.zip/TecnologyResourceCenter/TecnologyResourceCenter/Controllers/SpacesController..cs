﻿using Microsoft.AspNetCore.Mvc;
using TecnologyResourceCenter.Models;
using System.Collections.Generic;
using System.Linq;

namespace TecnologyResourceCenter.Controllers
{
    public class SpacesController : Controller
    {
        private static List<Space> _spaces = new List<Space>
        {
            new Space { Id = 1, Name = "Computer Laboratory 1", Location = "Building A - Floor 1", Capacity = 30, HourlyRate = 15.00m, IsAvailable = true },
            new Space { Id = 2, Name = "Multimedia Room", Location = "Building B - Floor 2", Capacity = 15, HourlyRate = 25.00m, IsAvailable = true },
            new Space { Id = 3, Name = "Streaming Room", Location = "Building C - Floor 1", Capacity = 5, HourlyRate = 30.00m, IsAvailable = false },
            new Space { Id = 4, Name = "Meeting Room", Location = "Administration - Floor 3", Capacity = 12, HourlyRate = 20.00m, IsAvailable = true },
            new Space { Id = 5, Name = "Robotics Laboratory", Location = "Building A - Floor 2", Capacity = 20, HourlyRate = 35.00m, IsAvailable = true }
        };

        public IActionResult Index()
        {
            return View(_spaces.OrderBy(s => s.Id).ToList());
        }

        public IActionResult Details(int id)
        {
            var space = _spaces.FirstOrDefault(s => s.Id == id);
            if (space == null)
            {
                return NotFound();
            }
            return View(space);
        }

        public IActionResult Available()
        {
            var availableSpaces = _spaces.Where(s => s.IsAvailable).ToList();
            return View(availableSpaces);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Space space)
        {
            if (!ModelState.IsValid)
            {
                return View(space);
            }

            space.Id = _spaces.Any() ? _spaces.Max(s => s.Id) + 1 : 1;
            _spaces.Add(space);

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var space = _spaces.FirstOrDefault(s => s.Id == id);
            if (space == null) return NotFound();

            return View(space);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Space updatedSpace)
        {
            if (id != updatedSpace.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(updatedSpace);
            }

            var existingSpace = _spaces.FirstOrDefault(s => s.Id == id);
            if (existingSpace == null) return NotFound();

            existingSpace.Name = updatedSpace.Name;
            existingSpace.Location = updatedSpace.Location;
            existingSpace.Capacity = updatedSpace.Capacity;
            existingSpace.HourlyRate = updatedSpace.HourlyRate;
            existingSpace.IsAvailable = updatedSpace.IsAvailable;

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var space = _spaces.FirstOrDefault(s => s.Id == id);
            if (space == null) return NotFound();

            return View(space);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var space = _spaces.FirstOrDefault(s => s.Id == id);
            if (space != null)
            {
                _spaces.Remove(space);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}