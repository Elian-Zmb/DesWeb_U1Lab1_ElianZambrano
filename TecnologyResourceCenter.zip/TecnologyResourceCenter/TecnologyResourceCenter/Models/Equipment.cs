﻿using System.ComponentModel.DataAnnotations;

namespace TecnologyResourceCenter.Models
{
    public class Equipment
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del equipo es obligatorio.")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "El nombre debe tener entre 3 y 100 caracteres.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "La categoría es obligatoria.")]
        public string Category { get; set; } = string.Empty;

        public string Brand { get; set; } = string.Empty;

        [Range(0.01, 10000.00, ErrorMessage = "La tarifa diaria debe ser mayor a cero y menor a $10,000.")]
        public decimal DailyRate { get; set; }

        [Range(0, 1000, ErrorMessage = "El stock no puede ser negativo ni exceder las 1000 unidades.")]
        public int Stock { get; set; }

        public bool IsOperational { get; set; }

        public string GetStatus()
        {
            if (!IsOperational) return "OUT OF SERVICE";
            if (Stock == 0) return "NOT AVAILABLE";
            if (Stock == 1) return "LAST UNIT";
            return "AVAILABLE";
        }

        public decimal CalculateRentalCost(int days)
        {
            if (days <= 0) return 0;
            return DailyRate * days;
        }
    }
}