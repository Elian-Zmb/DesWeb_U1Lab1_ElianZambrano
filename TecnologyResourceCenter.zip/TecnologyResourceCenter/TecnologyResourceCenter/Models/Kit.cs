﻿using System.ComponentModel.DataAnnotations;

namespace TecnologyResourceCenter.Models
{
    public class Kit
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del kit es obligatorio.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe especificar una categoría.")]
        public string Category { get; set; } = string.Empty;

        [Required(ErrorMessage = "El nivel es obligatorio.")]
        [RegularExpression("^(BEGINNER|INTERMEDIATE|ADVANCED)$", ErrorMessage = "El nivel solo puede ser: BEGINNER, INTERMEDIATE o ADVANCED.")]
        public string Level { get; set; } = string.Empty;

        [Range(0.01, 1000.00, ErrorMessage = "La tarifa diaria debe ser mayor a cero.")]
        public decimal DailyRate { get; set; }

        [Range(0, 500, ErrorMessage = "La cantidad no puede ser negativa.")]
        public int Quantity { get; set; }

        public bool IsOperational { get; set; }

        public string GetState()
        {
            if (!IsOperational) return "OUT OF SERVICE";
            if (Quantity == 0) return "OUT OF STOCK";
            if (Quantity <= 2) return "LIMITED STOCK";
            return "READY";
        }

        public decimal CalculateRentalCost(int days)
        {
            if (days <= 0) return 0;
            return DailyRate * days;
        }
    }
}