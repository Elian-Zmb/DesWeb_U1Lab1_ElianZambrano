﻿using System.ComponentModel.DataAnnotations;

namespace TecnologyResourceCenter.Models
{
    public class Accessory
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del accesorio es obligatorio.")]
        [StringLength(80, ErrorMessage = "El nombre no puede exceder los 80 caracteres.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "La marca es obligatoria.")]
        public string Brand { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe asignar una categoría.")]
        public string Category { get; set; } = string.Empty;

        [Range(0.01, 5000.00, ErrorMessage = "El precio debe ser un valor positivo.")]
        public decimal Price { get; set; }

        [Range(0, 10000, ErrorMessage = "La cantidad no puede ser negativa.")]
        public int Quantity { get; set; }
    }
}