﻿using System.ComponentModel.DataAnnotations;

namespace TecnologyResourceCenter.Models
{
    public class Space
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre del espacio es obligatorio.")]
        [StringLength(50, ErrorMessage = "El nombre no puede exceder los 50 caracteres.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "La ubicación es obligatoria.")]
        public string Location { get; set; } = string.Empty;

        [Range(1, 500, ErrorMessage = "La capacidad mínima es de 1 persona y máxima de 500.")]
        public int Capacity { get; set; }

        [Range(0.01, 5000.00, ErrorMessage = "La tarifa por hora debe estar entre $0.01 y $5,000.")]
        public decimal HourlyRate { get; set; }

        public bool IsAvailable { get; set; }

        public string GetAvailabilityStatus()
        {
            return IsAvailable ? "AVAILABLE" : "OCCUPIED";
        }

        public decimal CalculateUsageCost(int hours)
        {
            if (hours <= 0) return 0;
            return HourlyRate * hours;
        }
    }
}